// Database
#define MYSQL_HOST ""
#define MYSQL_USER ""
#define MYSQL_PASSWORD ""
#define MYSQL_DATABASE ""

// Server Description
#define server_name "Detroit Project Roleplay"
#define server_version "DTRP 0.0.2 - Create account sistem"